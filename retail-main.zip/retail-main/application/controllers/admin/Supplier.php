<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Supplier extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_supplier');
    }

    public function index()
    {
        $data['supplier'] = $this->M_supplier->get_all();
        $this->load->view('templates/header');
        $this->load->view('admin/supplier/index', $data);
    }

    public function tambah()
    {
        $this->load->view('templates/header');
        $this->load->view('admin/supplier/tambah');
    }

    public function simpan()
    {
        $data = [
            'nama_supplier' => $this->input->post('nama_supplier'),
            'alamat'        => $this->input->post('alamat'),
            'telepon'       => $this->input->post('telepon')
        ];
        $this->M_supplier->insert($data);
        redirect('admin/supplier');
    }

    public function edit($id)
    {
        $data['supplier'] = $this->M_supplier->get_by_id($id);
        $this->load->view('admin/supplier/edit', $data);
    }

    public function update($id)
    {
        $data = [
            'nama_supplier' => $this->input->post('nama_supplier'),
            'alamat'        => $this->input->post('alamat'),
            'telepon'       => $this->input->post('telepon')
        ];
        $this->M_supplier->update($id, $data);
        redirect('admin/supplier');
    }
}