<?php $this->load->view('templates/sidebar_admin'); ?>
<div class="content-wrapper">
    <section class="content pt-3">
        <div class="container-fluid">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Data Supplier</h3>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Supplier</th>
                                <th>Alamat</th>
                                <th>Telepon</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($supplier as $i => $s): ?>
                                <tr>
                                    <td><?= $i+1 ?></td>
                                    <td><?= $s->nama_supplier ?></td>
                                    <td><?= $s->alamat ?></td>
                                    <td><?= $s->telepon ?></td>
                                    <td>
                                        <a href="<?= base_url('admin/supplier/edit/' . $s->id_supplier) ?>" class="btn btn-sm btn-warning">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="<?= base_url('admin/supplier/hapus/' . $s->id_supplier) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus supplier ini?')">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
</div>